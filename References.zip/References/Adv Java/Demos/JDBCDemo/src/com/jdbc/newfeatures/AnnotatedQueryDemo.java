package com.jdbc.newfeatures;
/*
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.BaseQuery;

interface MyQueries extends BaseQuery {

	@Query(sql="select * from user")
	DataSet getAllUsers();
}




public class AnnotatedQueryDemo {

	/**
	 * @param args
	 */
	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			Connection conn =DriverManager.getConnection ("jdbc:oracle:thin:@192.168.67.177:1521:trgdb", "user1", "user1");
					
			
			
			Statement s1=conn.createStatement();
			ResultSet rs=s1.executeQuery("select * from Book");
			
			while (rs.next()) {
			
				
				InputStream is=rs.getBinaryStream(3);
				
				FileOutputStream fos=new FileOutputStream("logo1.gif"); 
			//System.out.println(rs.getString(1));
			int i=is.read();
			while(i!=-1){
				fos.write(i);
				i=is.read();
			}
			
			
	}
			
	}catch(Exception e){System.out.println("abc"+e);}
		
		
	}
	
	

}
*/