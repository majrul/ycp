package com.jdbc;

import java.sql.*;

class getdbinfo {
	public static void main(String args[]) throws SQLException {

		Connection conn;
		ResultSet rset;

		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/training", "root", "root");

			
			//ResultSet getPrimaryKeys(String catalog,String schema,String table)throws SQLException
			
			DatabaseMetaData dbmd = conn.getMetaData();
			rset = dbmd.getPrimaryKeys(null, "training", "student");
			
			while (rset.next()) {
				
				String table_name = rset.getString("TABLE_NAME");
				String column_name = rset.getString("COLUMN_NAME");
				String pk_name = rset.getString("PK_NAME");

				System.out.println("Table name              :" + table_name);
				System.out.println("\n Primary key column   :" + column_name);
				System.out.println("\n Primary key name     :" + pk_name);

				
				System.out.println("Get database Major Version : - "+ dbmd.getDatabaseMajorVersion());
				System.out.println("Get database Minor Version : - "+ dbmd.getDatabaseMinorVersion());
				System.out.println("get Database Product name : - "  + dbmd.getDatabaseProductName());
				System.out.println("get Database Product Version : - "+ dbmd.getDatabaseProductVersion());
				System.out.println("Get JDBC Driver Major Version :- "+ dbmd.getDriverMajorVersion());
				System.out.println("Get JDBC Driver Minor Version :- "+ dbmd.getDriverMinorVersion());
				System.out.println("Get driver Name : -" + dbmd.getDriverName());
				System.out.println("get driver version :- " + dbmd.getDriverVersion());
				System.out.println("Get JDBC Major version :- "+ dbmd.getJDBCMajorVersion());
				System.out.println("Get JDBC Minor version :- "+ dbmd.getJDBCMinorVersion());
				System.out.println("===========");
				
				String[] types = { "TABLE" };
				String catalog = conn.getCatalog();
				String schema = "training"; // name of the database
				
				rset = dbmd.getTables(catalog, schema, null, types);
				while (rset.next()) {
				       System.out.println(rset.getString(3));
				     }
			}

		} catch (Exception e) {
			System.out.println("Sql exception   " + e.getMessage());
		}

	}
}
