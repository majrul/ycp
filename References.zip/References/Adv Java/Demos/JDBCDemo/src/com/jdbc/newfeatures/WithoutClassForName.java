package com.jdbc.newfeatures;

import java.sql.*;
import java.sql.DriverManager;

public class WithoutClassForName {
	public static void main(String a[]) {
		try {
			//Class.forName(load driver);
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database", "root", "root");
			// Query the employee names
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select id, scourse, sname from student");
			while (rs.next()) {
				System.out.println(rs.getString(1) + "  " + rs.getString(2));
			}
			System.in.read();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
