package com.jdbc.newfeatures;

import java.io.Writer;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Statement;

public class BlobDemo {

	public static void main(String[] args) {

		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@192.168.224.26:1521:trgdb", "user2",
					"user2");
			/*
			 * CREATE TABLE Inventory ( ID NUMBER(4) , Name VARCHAR(10), Photo
			 * BLOB )
			 */
			PreparedStatement pstmt = conn
					.prepareStatement("insert into Inventory values(?,?,?)");
			Blob blogEntry = conn.createBlob();
			blogEntry.setBinaryStream(234224);
			pstmt.setInt(1, 100);
			pstmt.setString(2, "Habib");
			pstmt.setBlob(3, blogEntry);

			pstmt.execute();

			Statement s1 = conn.createStatement();
			ResultSet rs = s1.executeQuery("select * from Inventory");

			while (rs.next()) {

				System.out.println(rs.getString(1));
				System.out.println(rs.getBinaryStream(2).read());
				System.out.println(rs.getBinaryStream(3).read());
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
