package com.jdbc;

import java.sql.*;

class print_columns {
	static Connection conn;
	static Statement stmt;
	static ResultSet rset;

	public static void main(String args[]) throws SQLException {

		String query = "select * from student";

		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/database", "root", "root");

			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rset.getMetaData();

			int numberOfColumns = rsmd.getColumnCount();

			for (int i = 1; i <= numberOfColumns; i++) {
				if (i > 1)
					System.out.print(", ");
				String columnName = rsmd.getColumnName(i);
				System.out.print(columnName);
			}
			System.out.println("\n===============================================");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
			while (rset.next()) {
				System.out.println("\n");
				for (int i = 1; i <= numberOfColumns; i++) {
					if (i > 1)
						System.out.print(", ");
					String columnValue = rset.getString(i);
					System.out.print(columnValue);
				}
				System.out.print(" ");
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			stmt.close();

		}
	}
}
