package com.jdbc;

import java.sql.*;

public class Select {

	public static void main(String[] args) {

		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/database", "root", "root");

			// Query the employee details
			Statement stmt = conn.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			ResultSet rset = stmt
					.executeQuery("select sroll, sname, scourse from student");

			// Print the no and name
			System.out
					.println("Student ID    Student  Name     Student course");
			System.out
					.println("===============================================\n");
			while (rset.next()) {
				System.out.println(rset.getInt(1) + "              "
						+ rset.getString(2) + "              "
						+ rset.getString(3));

				
			      /* rset.absolute(5); // moves the cursor to the fifth row of rs
			       System.out.println(rset.getInt(1) + "              "
							+ rset.getString(2) + "              "
							+ rset.getString(3));*/

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
