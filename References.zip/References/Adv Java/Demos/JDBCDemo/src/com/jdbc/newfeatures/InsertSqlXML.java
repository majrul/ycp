package com.jdbc.newfeatures;

import java.sql.*;

public class InsertSqlXML {

	public static void main(String[] args) {

		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database", "root", "root");
			Statement s1 = conn.createStatement();
			
			/*create table article1 (id number(2), data XMLTYPE);*/
			
			boolean b = s1
					.execute("INSERT INTO ARTICLE1 VALUES (1, XMLTYPE('<roster> <student>Arti</student><student>Bharathi</student><student>Sarathi</student></roster>') )");
			System.out.println("Record Inserted");
			
			/*<roster> 
			 * 	<student>Arti</student>
			 * 	<student>Bharathi</student>
			 * 	<student>Sarathi</student>
			 * </roster> */
			
			System.out.println("Retriving record");

			/*SELECT id, 
			   extract(a.data, '/roster/student/text()').getStringVal()
			   "Student Name"
			   FROM article1 a 
			   WHERE data IS NOT NULL
			 */

			ResultSet rs = s1
					.executeQuery("SELECT id, extract(a.data, '/roster/student/text()').getStringVal() \"Student Name\" FROM article1 a WHERE data IS NOT NULL");

			while (rs.next()) {

				System.out.println("  ID       DATA  ");
				System.out.println(" ------------------ ");
				System.out.println(rs.getInt(1) + "      " + rs.getString(2));
			}
		} catch (SQLException sx) {
			for (Throwable e : sx) {
				System.err.println("Error encountered: " + e);
			}
			/*
			System.out.println("Error encountered: " + sx.getMessage());
			SQLException nextException = sx.getNextException();
			while(nextException != null){
				System.out.println("Error encountered: " + nextException.getMessage());
				nextException = nextException.getNextException();
			} */
		}
	}
}
