package com.jdbc.newfeatures;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class ImageBlobDemo {

	public static void main(String[] args) {

		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			/*
			 * CREATE TABLE Person ( ID varchar(4) , Name VARCHAR(10), Photo BLOB )
			 */
			PreparedStatement pstmt = conn
					.prepareStatement("insert into Person values(?,?,?)");
			Blob blogEntry = conn.createBlob();
			FileInputStream fis = new FileInputStream("C:\\softwares\\Desert.jpg");
			byte data[] = new byte[100000];
			fis.read(data);
			blogEntry.setBytes(1, data);
			pstmt.setInt(1, 100);
			pstmt.setString(2, "Shrilata");
			pstmt.setBlob(3, blogEntry);

			pstmt.execute();

			Statement s1 = conn.createStatement();
			ResultSet rs = s1.executeQuery("select * from Person");

			while (rs.next()) {

				System.out.println("in rs");
				InputStream is = rs.getBinaryStream(3);

				FileOutputStream fos = new FileOutputStream("photo2.jpg");

				int i = is.read();
				while (i != -1) {
					fos.write(i);
					i = is.read();
				}
			}

		} catch (Exception e) {
			System.out.println("Error :  " + e.getMessage());
		}
	}
}
