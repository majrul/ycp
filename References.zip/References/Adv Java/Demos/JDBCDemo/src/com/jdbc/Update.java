package com.jdbc;

import java.sql.*;

public class Update {

	public static void main(String[] args) {

		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/training", "root", "root");

			// Query the employee details
			Statement stmt = conn.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			ResultSet rset = stmt.executeQuery("select * from student");

			// Print the no and name
			// System.out.println("Student ID    Student  Name     Student course");

			rset.last();
			System.out.println(rset.getRow() + "  " + rset.getInt(1) + "  "
					+ rset.getString(2) + "              " + rset.getString(3));

			rset.updateString("sname", "Soha T"); // update cells via column name
			rset.updateInt("sroll", 99);
			rset.updateRow(); // update the row in the data source
			
			System.out.println(rset.getRow() + "  " + rset.getInt(1) + "  "
					+ rset.getString(2) + "              " + rset.getString(3));
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
