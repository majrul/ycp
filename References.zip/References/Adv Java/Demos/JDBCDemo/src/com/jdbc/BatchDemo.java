package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class BatchDemo {
	Connection con;
	Statement stmt;

	public BatchDemo() {
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/database", "root", "root");
		} catch (Exception e) {
			System.out.println("Error in connection" + e);
		}
	}

	// Create table in database server

	public void batchProcess() {
		try {
			stmt.addBatch("insert into Student values(1,'BTech','Ram Kumar',100)");
			stmt.addBatch("insert into Student values(2,'BTech','Shayam Kumar',101)");
			stmt.addBatch("insert into Student values(3,'MCA','Ritu Kumari',102)");
			stmt.addBatch("insert into Student values(5,'BTech','Suresh Sharma',103)");
			int i[] = stmt.executeBatch();
			for (int j : i) {
				if (j != 0)
					System.out.println("Executed successfully");
				else
					System.out.println("Not Executed successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void showRecords() {
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from Student");
			while (res.next()) {
				System.out.print(res.getString(1));
				System.out.print("\t" + res.getString(2));
				System.out.print("\t" + res.getString(3));
				System.out.println("\t" + res.getString(4));
			}

		} catch (Exception e) {
			System.out.println("Error in fetching data" + e);
		}
	}

	public static void main(String[] args) {
		BatchDemo obj = new BatchDemo();

		obj.batchProcess();
		obj.showRecords();
	}
}
