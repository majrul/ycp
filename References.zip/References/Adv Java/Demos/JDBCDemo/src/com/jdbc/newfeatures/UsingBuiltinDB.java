package com.jdbc.newfeatures;
import java.sql.*;
import java.sql.DriverManager;
public class UsingBuiltinDB {

	public static void main(String args[]){
		try{
		Connection conn 
		   = DriverManager.getConnection("jdbc:derby:TestDB;create=true");
		Statement stmt = conn.createStatement();
		stmt.execute("create table CLIENT(ID int primary key,FIRSTNAME varchar(40),SURNAME varchar(40))");
		stmt.execute("insert into CLIENT values (1, 'Joe', 'Bloggs')");
		stmt.execute("insert into CLIENT values (2, 'Jane', 'Doe')");
		stmt.execute("insert into CLIENT values (3, 'John', 'Smith')");
		} catch (Exception e){ System.out.println(e.getMessage());
		}
	}
}
