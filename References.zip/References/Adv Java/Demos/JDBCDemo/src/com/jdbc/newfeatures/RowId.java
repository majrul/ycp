package com.jdbc.newfeatures;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.RowIdLifetime;
import java.sql.SQLException;
import java.sql.Statement;
public class RowId {

	public static void main(String[] args) {
		try {

			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");

			// Query the employee names
			DatabaseMetaData rd = conn.getMetaData();
			// OracleDatabaseMetaData rd=conn.getMetaData();
			RowIdLifetime rowIdLifeTime = rd.getRowIdLifetime();
			System.out.println(rowIdLifeTime.name());
			
			if (rowIdLifeTime != RowIdLifetime.ROWID_UNSUPPORTED) {
				Statement stmt = conn.createStatement();
				// Row Id support is there for this Data source.

				ResultSet rs = stmt
						.executeQuery("select rowid from student where sname='Soha'");
				rs.next();
				java.sql.RowId rowId = rs.getRowId("rowid");
				System.out.println(rowId.toString());
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
}
