package com.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Insert {

	public static void main(String[] args) {
		
		try	{
			
			DriverManager.registerDriver (new com.mysql.jdbc.Driver());
			Connection conn = DriverManager.getConnection (
					"jdbc:mysql://localhost:3306/training", "root", "root");
			
			
			Statement stmt = conn.createStatement (); 
			for(int i = 0;i<=100;i++)
			{
			int count = stmt.executeUpdate ("insert into student values("+(4070+i)+",'Soha','MBA')");
			}
			
			System.out.println("Record is inserted successfully !!");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		
	}

}
