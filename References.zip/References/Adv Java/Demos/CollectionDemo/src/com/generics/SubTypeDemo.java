package com.generics;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

public class SubTypeDemo {
public static void main(String args[]){
	ArrayList<Integer> ai = new ArrayList<Integer>();
	//ArrayList<Object> ao = ai; // If it is allowed at compile time,
	//ao.add(new Object());
	Integer i = ai.get(0); // This would result in 
					// runtime ClassCastException
	
	ArrayList<Number> an = new ArrayList<Number>();
	List<Integer> li = new ArrayList<Integer>();
	Collection<Integer> ci = new ArrayList<Integer>();
	Collection<String> cs = new Vector<String>(4);
	an.add(new Integer(5));
	an.add(new Long(1000L));
	//an.add(new String(�hello�)); // compile error

}
}
