package com.newUtilities.deque;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SampleMap {
	int c=8;
	class Demo
	{
		public void see()
		{
			int c=9;
			System.out.println("Value of c= "+c);
		}
	}
public static void main(String args[])
{
	List<Object> list=new ArrayList<Object>();
	list.add("take");
	list.add("better");
	System.out.println(list);
	
	
}
}
