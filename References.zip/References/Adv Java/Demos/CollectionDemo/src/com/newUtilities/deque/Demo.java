package com.newUtilities.deque;

public class Demo {
String name;
String role;
public Demo(String name,String role)
{
	this.name=name;
	this.role=role;
}
@Override
public String toString() {
	return "Demo [name=" + name + ", role=" + role + ", toString()="
			+ super.toString() + "]";
}
}
