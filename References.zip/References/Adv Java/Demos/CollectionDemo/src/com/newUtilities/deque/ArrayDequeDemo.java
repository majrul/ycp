package com.newUtilities.deque;

import java.io.Console;
import java.util.*;

public class ArrayDequeDemo {
	public static void main(String[] args) {
		Console c = System.console();
		if (c == null) {
			System.err.println("Console object is not available");
			System.exit(1);
		}
		ArrayDeque<String> dqname = new ArrayDeque<String>();
		String name = null;
		name = c.readLine("Enter any String: ");
		dqname.add(name);
		show(dqname);

		name = c
				.readLine("Enter any string to add on starting point of deque by addFirst():");
		dqname.addFirst(name);
		show(dqname);
		name = c
				.readLine("Enter any string to add on ending point of deque by addLast():");
		dqname.addLast(name);
		show(dqname);
		name = c
				.readLine("Enter any string to add on starting point of deque by offerfirst() :");
		dqname.offerFirst(name);
		show(dqname);
		name = c
				.readLine("Enter any string to add on ending point of deque by offerlast() :");
		dqname.offerLast(name);
		show(dqname);
		System.out.println("Getting the first element by using getFirst()");
		String str1 = dqname.getFirst();
		System.out.println("First element is  : " + str1);
		System.out.println("Getting the Last element by using getLast()");
		str1 = dqname.getLast();
		System.out.println("Last element is  : " + str1);

		System.out.println("Getting the first element by using peekFirst()");
		str1 = dqname.peekFirst();
		System.out.println("First element is  : " + str1);

		System.out.println("Getting the Last element by using peekLast()");
		str1 = dqname.peekLast();
		System.out.println("Last element is  : " + str1);
		System.out.println("Removing the first element by using removeFirst()");
		str1 = dqname.removeFirst();
		show(dqname);
		System.out.println("Removing the Last element by using removeLast()");
		str1 = dqname.removeLast();
		show(dqname);
		System.out.println("Removing the first element by using pollFirst()");
		str1 = dqname.pollFirst();
		show(dqname);
		System.out.println("Removing the Last element by using pollFirst()");
		str1 = dqname.pollLast();
		show(dqname);
	}

	static void show(ArrayDeque<String> dqname) {
		Iterator<String> nameIter = dqname.iterator();
		while (nameIter.hasNext())
			System.out.println(nameIter.next());
	}

}
