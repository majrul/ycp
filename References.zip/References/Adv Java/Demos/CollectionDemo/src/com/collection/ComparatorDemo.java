package com.collection;

import java.util.*;

class Employee1 implements Comparable {
	int EmpID;
	String Ename;
	double Sal;
	static int i;

	public Employee1() {
		EmpID = i++;
		Ename = "Unknown";
		Sal = 0.0;
	}

	public Employee1(String ename, double sal) {
		EmpID = i++;
		Ename = ename;
		Sal = sal;
	}

	public String toString() {
		return "EmpID : " + EmpID + "\n" + "Ename : " + Ename + "\n" + "Sal : "
				+ Sal;
	}

	public int compareTo(Object o) {
		if (this.Sal == ((Employee1) o).Sal)
			return 0;
		else if (this.Sal > ((Employee1) o).Sal)
			return 1;
		else
			return -1;
	}
}

class ComparatorDemo {
	public static void main(String[] args) {
		//Employee1 e1 = new Employee1("harry", 40000.00);
		TreeSet ts1 = new TreeSet();
		ts1.add(new Employee1("harry", 40000.00));
		ts1.add(new Employee1("Mary", 20000.00));
		ts1.add(new Employee1("Peter", 50000.00));
		ts1.add(new Employee1("richard", 70000.00));

		Iterator itr = ts1.iterator();
		while (itr.hasNext()) {
			Object element = itr.next();
			System.out.println(element + "\n");
		}
		System.out.println();

	}
}
