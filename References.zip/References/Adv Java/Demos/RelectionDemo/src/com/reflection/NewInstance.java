package com.reflection;

import java.lang.reflect.*;

public class NewInstance {
	public NewInstance() {
	}

	public NewInstance(int a, int b) {
		System.out.println("a = " + a + " b = " + b);
	}

	public static void main(String args[]) {
		try {
			Class cls = Class.forName("com.reflection.NewInstance");
			Class partypes[] = new Class[2];
			partypes[0] = Integer.TYPE;
			partypes[1] = Integer.TYPE;
			Constructor ct = cls.getConstructor(partypes);
			Object arglist[] = new Object[2];
			arglist[0] = 78;
			arglist[1] = 90;
			arglist[2] = 80;
			Object retobj = ct.newInstance(arglist);
		} catch (Throwable e) {
			System.err.println(e);
		}
	}
}
