package com.reflection;

import java.lang.reflect.*;
import java.awt.*;

class SampleName {

   public static void main(String[] args) {
      String b = new String();
      printName(b);
   }

   static void printName(Object o) {
       Class c = o.getClass();
       String s = c.getName();
       System.out.println(s);
   }
}
