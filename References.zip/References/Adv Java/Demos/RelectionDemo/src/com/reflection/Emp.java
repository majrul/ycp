package com.reflection;

import java.lang.reflect.Field;
import static java.lang.System.*;

public class Emp {
	int age = 0;

	public static void main(String[] args) {
		Emp e = new Emp();
		Class c = e.getClass();
		String fmt = "%6S:  %-12s = %s%n";
		Field f = null;
		try {
			f = c.getDeclaredField("age");
			out.format(fmt, "before", "age", e.age);
			f.setInt(e, 20);
			out.format(fmt, "After", "age", f.getInt(e));
			out.println("---------------------");
			out.println("After Change : " + e.age);
		} catch (NoSuchFieldException e1) {
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			e1.printStackTrace();
		}
	}
}
