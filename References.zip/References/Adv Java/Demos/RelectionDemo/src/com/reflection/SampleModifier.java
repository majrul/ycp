package com.reflection;

import java.lang.reflect.*;
import java.awt.*;
class SampleModifier {
   public static void main(String[] args) {
      String s = new String();
      printModifiers(s); 
   }
   public static void printModifiers(Object o) {
      Class c = o.getClass();
      String s = null;
      Class f = s.getClass();
      System.out.println(f.getCanonicalName());
	   //Class c = java.io.InputStream.class;
      int m = c.getModifiers();
      if (Modifier.isPublic(m))
         System.out.println("public");
      if (Modifier.isAbstract(m))
         System.out.println("abstract");
      if (Modifier.isFinal(m))
         System.out.println("final");
   }
}
