package com.reflection;

import java.lang.reflect.*;

class SampleMethod {
	public static void main(String[] args) {
		showMethods(new String());
	}

	static void showMethods(Object o) {
		Class c = o.getClass();
		Method[] theMethods = c.getMethods();
		for (int i = 0; i < theMethods.length; i++) {
			System.out.println("Name:" + theMethods[i].getName());
			System.out.println("Return Type:" + 
					theMethods[i].getReturnType());
		}
	}
}
