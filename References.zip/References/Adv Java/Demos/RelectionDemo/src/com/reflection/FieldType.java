package com.reflection;

import java.lang.reflect.*;

class FieldType {
	public boolean[][] b = { { false, false }, { true, true } };
	public String name = "Alice";

	public static void main(String[] args) {
		Class c = null;
		try {
			c = Class.forName("com.reflection.FieldType");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Field f = null;
		try {
			f = c.getField("name");
		} catch (SecurityException e1) {
			e1.printStackTrace();
		} catch (NoSuchFieldException e1) {
			e1.printStackTrace();
		}
		System.out.println("Type : " + f.getType());
		System.out.println("GenericType: " + f.getGenericType());
	}
}
