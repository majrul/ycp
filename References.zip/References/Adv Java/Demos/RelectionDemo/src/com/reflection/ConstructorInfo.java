package com.reflection;

import java.lang.reflect.*;

public class ConstructorInfo {
	
   public ConstructorInfo() {
	}

	protected ConstructorInfo(int i, double d) {
	}

	private ConstructorInfo(int i, double d,double j) {
	}
}
