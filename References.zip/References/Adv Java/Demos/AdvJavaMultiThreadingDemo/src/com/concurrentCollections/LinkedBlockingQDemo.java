package com.concurrentCollections;

import java.util.concurrent.*;

public class LinkedBlockingQDemo {
	public static void main(String[] args) {
		BlockingDeque<String> deque = new LinkedBlockingDeque<String>();

		deque.addFirst("1");
		deque.addLast("2");

		try {
			String two = deque.takeLast();
			String one = deque.takeFirst();
			System.out.println(two + "    " + one);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
