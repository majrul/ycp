package com.innerclass;

public class OuterClassLocal {
	final int outerVariable = 10000;
    static int staticOuterVariable = 2000;
     
    Object run() {
        int localVariable = 666;
        final int finalLocalVariable = 300;
         
        class LocalClass {
            int innerVariable = 40;
             
            int getSum(int parameter) {
                // Cannot access localVariable here
            	System.out.println("localvariable: "+finalLocalVariable);
                return outerVariable + staticOuterVariable + 
                       finalLocalVariable + innerVariable + parameter+100;
            }       
        }
        LocalClass local = new LocalClass();
        System.out.println(local.getSum(5));
        return local;
    }
    public static void main(String[] args) {
        OuterClass outer = new OuterClass();
        outer.run();
        //System.out.println("" + outer.run());
    }
     
}
