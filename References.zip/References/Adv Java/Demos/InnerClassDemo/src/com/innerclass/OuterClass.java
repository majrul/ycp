package com.innerclass;

public class OuterClass {
	int outerVariable = 100;
	static int staticOuterVariable = 200;
	
	class MemberClass {
		int innerVariable = 20;
	
		int getSum(int parameter) {
			return innerVariable + outerVariable + staticOuterVariable+parameter;
		}
	}

	public static void main(String[] args) {
		OuterClass outer = new OuterClass();
		MemberClass inner = outer.new MemberClass();
		MemberClass inner1 = outer.new MemberClass();
		MemberClass inner2 = outer.new MemberClass();
		System.out.println(inner.getSum(3));
		outer.run();
	}

	void run() {
		MemberClass localInner = new MemberClass();
		System.out.println(localInner.getSum(5));
	}
}