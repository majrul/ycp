package com.regexp;

import java.util.regex.*;

public class RegExTest1 {
	public static void main(String[] args) {

		String input = "A11";
		//Checks for string that start with upper case alphabet and end with digit. 
		Pattern p = Pattern.compile("[A-Z]$");
		Matcher m = p.matcher(input);
		if (!m.find()) {
			System.out.println("Enter  correct code");
		}
		else
		System.out.println(m.group());
	}
}
